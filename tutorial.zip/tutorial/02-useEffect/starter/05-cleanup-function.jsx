const CleanupFunction = () => {
  return <h2>cleanup function</h2>;
};

export default CleanupFunction;
