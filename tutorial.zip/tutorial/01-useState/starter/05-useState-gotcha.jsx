const UseStateGotcha = () => {
  return <h2>useState "gotcha"</h2>;
};

export default UseStateGotcha;
